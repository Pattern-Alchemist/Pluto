export class AutoResolveAgent {
  async monitor() { console.log('auto-resolve (stub)') }
}
