export default function Consultation() {
  return (
    <div className="space-y-2">
      <h2 className="text-2xl font-semibold">Video Consultation</h2>
      <p className="text-slate-400">LiveKit token route is stubbed at /api/video/token</p>
    </div>
  )
}
